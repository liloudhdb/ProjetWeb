<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Vie d'ECE</title>
    <link rel="icon" href="../img/ECE_LOGO_CARRE.jpg" type="image/jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <?php 
        include("mep/header.php");
        ?>
    </div>

    <div class="content">
      <!-- Contenu principal de la page -->
       
    </div>

    <?php
    include("mep/footer.php");
    ?>
</body>
</html>